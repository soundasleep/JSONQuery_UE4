// Copyright 1998-2013 Epic Games, Inc. All Rights Reserved.
#include "JSONQueryPrivatePCH.h"

IMPLEMENT_MODULE(FDefaultGameModuleImpl, JSONQuery);